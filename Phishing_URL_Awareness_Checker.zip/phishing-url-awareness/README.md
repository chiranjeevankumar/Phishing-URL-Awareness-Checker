# EWB Phishing URL Awareness Checker

## Overview
Phishing is when someone uses a fake link or message to try to get private information. This small Python program checks the text of a URL and points out a few warning signs that a person can look at before trusting a link.

## Features
- Checks for an `@` symbol
- Flags URLs longer than 100 characters
- Flags an IP address used as the hostname
- Flags hostnames with five or more parts
- Flags punycode-style hostnames containing `xn--`
- Flags URLs using HTTP
- Allows several sample URLs to be checked in one run
- Handles empty and malformed input without stopping unexpectedly
- Shows a review message when warning signs are found

## Requirements
- Python 3.10 or later
- No extra Python packages

## How to Run
Open a terminal in this folder and run:

Windows:
```bash
python phishing_checker.py
```

Mac or Linux:
```bash
python3 phishing_checker.py
```

Enter one of the sample URLs from `tests/test_samples.md`. Type `q` when you want to quit.

## Example Output
```text
EWB Phishing URL Awareness Checker
Text checks only - this program does not open URLs.

Enter a sample URL (or type q to quit): http://192.0.2.10/account

Result:
- Uses an IP address instead of a familiar domain.
- Uses HTTP. HTTPS alone does not prove trust.

REVIEW CAREFULLY: 2 warning sign(s) found.
Never enter passwords from unexpected links.
```

## Testing
The five sample cases and their expected results are listed in `tests/test_samples.md`. Run the program with each sample and compare the output with the table. Record your Python version, operating system and test date before submitting.

## Screenshots
Save your own screenshots of the program running in this folder:
- `screenshots/sample_run.png`
- `screenshots/test_results.png`

The screenshots should show your real terminal output and completed test table. Do not use example images as proof of a run.

## Improvements
1. **Repeat check and quit option** - I added a loop so I can inspect more than one sample URL without starting the program again.
2. **Clear warning summary** - the program counts warning signs and prints a review message when it finds any.
3. **Input error handling** - malformed URL text is handled with a message instead of letting the program stop with an error.

## Limitations
This is only a beginner learning project. It reads URL text and does not open websites, check reputation services or scan for malware. A URL with no listed warning signs can still be dangerous, and a URL with warning signs is not automatically malicious.

## Ethical Use
Use the sample strings for learning. Do not collect passwords, send phishing messages, or test websites without permission.

## Author
Chiranjeevan Kumar Raavi

Before submitting, please run the program on your own device, fill in the actual test evidence, and make sure you can explain how each check works.
