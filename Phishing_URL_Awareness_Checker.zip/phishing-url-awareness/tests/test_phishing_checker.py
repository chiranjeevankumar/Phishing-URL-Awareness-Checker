import unittest
from phishing_checker import inspect_url


class PhishingCheckerTests(unittest.TestCase):
    def test_normal_example(self):
        result = inspect_url("https://www.example.com/login")
        self.assertTrue(any("No listed warning signs" in item for item in result))

    def test_ip_and_http(self):
        result = inspect_url("http://192.0.2.10/account")
        self.assertTrue(any("IP address" in item for item in result))
        self.assertTrue(any("Uses HTTP" in item for item in result))

    def test_at_symbol(self):
        result = inspect_url("http://example.com@sample.invalid/login")
        self.assertTrue(any("@ symbol" in item for item in result))

    def test_many_hostname_parts(self):
        result = inspect_url("https://a.b.c.d.e.example.invalid/path")
        self.assertTrue(any("hostname segments" in item for item in result))

    def test_punycode(self):
        result = inspect_url("https://xn--example.invalid/")
        self.assertTrue(any("punycode-style hostname" in item for item in result))

    def test_empty_input(self):
        self.assertEqual(inspect_url("  "), ["No URL entered."])

    def test_malformed_input(self):
        self.assertEqual(inspect_url("http://[bad"), ["This text is not a valid URL format."])


if __name__ == "__main__":
    unittest.main()
