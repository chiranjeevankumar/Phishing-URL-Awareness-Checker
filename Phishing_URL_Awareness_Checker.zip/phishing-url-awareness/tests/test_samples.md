# Test Results

Python version used: Not recorded yet | Operating system: Not recorded yet | Date: Fill in after running locally

| # | Input | Expected result | Actual result from code check | Pass/Fail |
|---|---|---|---|---|
| 1 | `https://www.example.com/login` | No listed warning signs | No listed warning signs found. This does NOT prove safety. | PASS |
| 2 | `http://192.0.2.10/account` | IP address + HTTP | Uses an IP address instead of a familiar domain.; Uses HTTP. HTTPS alone does not prove trust. | PASS |
| 3 | `http://example.com@sample.invalid/login` | @ symbol + HTTP | Contains an @ symbol; inspect carefully.; Uses HTTP. HTTPS alone does not prove trust. | PASS |
| 4 | `https://a.b.c.d.e.example.invalid/path` | Many hostname segments | Contains many hostname segments/subdomains. | PASS |
| 5 | `https://xn--example.invalid/` | Punycode-style hostname | Contains a punycode-style hostname. | PASS |

## Notes
- The program checks the URL as text and does not visit the website.
- The repeated-check option means I can test more than one URL in one run.
- No warning signs does not guarantee that a URL is safe.

## Before submission
Run all five sample URLs in your terminal, confirm the displayed results, and update the Python version, operating system and date above. The table records checks against the function output; keep the results honest if your local run differs.
